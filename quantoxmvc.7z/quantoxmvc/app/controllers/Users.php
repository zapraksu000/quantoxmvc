<?php

class Users extends Controller
{
    public function __construct()
    {
        $this->userModel = $this->model('User');
    }

    public function register()
    {

        $data = [
            'name' => '',
            'email' => '',
            'password' => '',
            'confirmPassword' => '',
            'type' => '',
            'subtype' => '',

            'nameError' => '',
            'emailError' => '',
            'passwordError' => '',
            'confirmPasswordError' => '',
            'typeError' => '',
            'subtypeError' => ''


        ];

        //provera za POST
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            $data = [
                'name' => trim($_POST['name']),
                'email' => trim($_POST['email']),
                'password' => trim($_POST['password']),
                'confirmPassword' => trim($_POST['confirmPassword']),
                'type' => trim($_POST['type']),
                'subtype' => trim($_POST['subtype']),

                'nameError' => '',
                'emailError' => '',
                'passwordError' => '',
                'confirmPasswordError' => '',
                'typeError' => '',
                'subtypeError' => '',

            ];

            $nameValidation = "/^[a-zA-Z]*$/";
            $passwordValidation = "/^(.{0,7}|[^a-z]*|[^\d]*)$/i";

            //provera da li su samo slova za ime
            if (empty($data['name'])) {
                $data['nameError'] = "Please enter name.";
            } elseif (!preg_match($nameValidation, $data['name'])) {
                $data['nameError'] = 'Name can only contain letters.';
            }

            //provera emaila
            if (empty($data['email'])) {
                $data['emailError'] = 'Please enter email.';
            } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                $data['emailError'] = 'Please enter the correct email format.';
            } else {
                if ($this->userModel->findUserByEmail($data['email'])) {
                    $data['emailError'] = 'Email is taken.';
                }
            }

            //provera passworda
            if (empty($data['password'])) {
                $data['passwordError'] = 'Please enter password.';
            } elseif (strlen($data['password']) < 8) {
                $data['passwordError'] = 'Password must be 8 characters or more.';
            } else if (preg_match($passwordValidation, $data['password'])) {
                $data['passwordError'] = 'Password must have at least one numeric value.';
            }

            //provera confirm password
            if (empty($data['confirmPassword'])) {
                $data['confirmPasswordError'] = 'Please enter password.';
            } else {
                if ($data['password'] != $data['confirmPassword']) {
                    $data['confirmPasswordError'] = 'Passwords do not match.';
                }
            }

            if (empty($data['type'])) {
                $data['typeError'] = "Please select type.";
            }

            if (empty($data['subtype'])) {
                $data['subtypeError'] = "Please select subtype.";
            }

            //provera da li ima gresaka
            if (empty($data['nameError']) && empty($data['emailError']) && empty($data['passwordError']) && empty($data['confirmPasswordError']) && empty($data['typeError']) && empty($data['subtypeError'])) {

                // Hash password
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);

                //registracija korisnika
                if ($this->userModel->register($data)) {

                    header('location: ' . URLROOT . '/users/login');
                } else {
                    die("Something went wrong");
                }

            }
        }

        $this->view('users/register', $data);
    }

    public function login()
    {

        $data = [
            'email' => '',
            'password' => '',
            'emailError' => '',
            'passwordError' => ''
        ];

        //provera za post
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            $data = [
                'email' => trim($_POST['email']),
                'password' => trim($_POST['password']),
                'emailError' => '',
                'passwordError' => ''
            ];

            if (empty($data['email'])) {
                $data['emailError'] = "Enter email";
            }

            if (empty($data['password'])) {
                $data['passwordError'] = "Enter password";
            }

            //provera da li ima gresaka
            if (empty($data['emailError']) && empty($data['passwordError'])) {
                $loggedInUser = $this->userModel->login($data['email'], $data['password']);

                if ($loggedInUser) {
                    //print_r($loggedInUser);
                    $this->createUserSession($loggedInUser);
                } else {
                    $data['passwordError'] = 'Incorrect email or password';

                    //$this->view('users/login', $data);
                }
            }

        } else {
            $data = [
                'email' => '',
                'password' => '',
                'emailError' => '',
                'passwordError' => ''
            ];
        }

        $this->view('users/login', $data);
    }

    public function createUserSession($user)
    {

        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['user_email'] = $user['user_email'];
        $_SESSION['user_name'] = $user['user_name'];

        header('location:' . URLROOT . '/pages/index');

    }

    public function logout() {
        unset($_SESSION['user_id']);
        unset($_SESSION['user_email']);
        unset($_SESSION['user_name']);
        header('location:' . URLROOT . '/users/login');
    }

    public function result() {

        $data = [
            'search' => ''
        ];

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            $data = [
                'search' => trim($_POST['search']),
            ];

            //samo slova, brojevi, @ i tacka (za email)
            $searchValidation = "/^[a-zA-Z0-9@.]*$/";

            if(!empty($data['search'])) {

                if (!preg_match($searchValidation, $data['search'])) {
                    echo "<h1> Search must contain only letters, numbers, @ and dot </h1>>";
                } else {

                //print_r($data);
                if (isLoggedIn()) {
                    //print_r($data);
                    $this->userModel->search($data['search']);

                } else {

//                    setcookie('search', $data['search'], time() + (86400), "/"); // 86400 = 1 dan
//                    echo $_COOKIE['search'];

                    echo "<h1>Please login or register to use search</h1>";
                    $this->view('users/login', $data);

                }
            }
            } else {
                echo "<h1> Search must not be empty </h1>";
            }

        }

        $this->view('users/result', $data);

    }
}