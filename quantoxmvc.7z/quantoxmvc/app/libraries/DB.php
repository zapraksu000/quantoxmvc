<?php

class DB {
    private static $_instance;
    private $_pdo,
            $_query;

    private function __construct()
    {

        $conn = "mysql:host=". DB_HOST . ";dbname=" . DB_NAME;
        //echo $conn;
        try {
            $this->_pdo = new PDO($conn, DB_USER, DB_PASS);
            //echo "povezano";
        } catch (PDOException $e) {
            die($e->getMessage());
        }

    }

    public static function getInstance() {
        if (!ISSET(self::$_instance)) {
            self::$_instance = new DB();
        }
        return self::$_instance;
    }

    //priprema upita
    public function query($sql) {
        $this->_query = $this->_pdo->prepare($sql);
    }


    //metoda za bindovanje parametra
    public function bind($param, $value, $type = null) {
        switch (is_null($type)) {
            case is_int($value):
                $type = PDO::PARAM_INT;
                break;
            case is_bool($value):
                $type = PDO::PARAM_BOOL;
                break;
            case is_null($value):
                $type = PDO::PARAM_NULL;
                break;
            default:
                $type = PDO::PARAM_STR;
        }
        $this->_query->bindValue($param, $value, $type);
    }

    //izvrsavanje upita
    public function execute() {
        return $this->_query->execute();
    }

    //vraca sve rezultate
    public function resultSet() {
        $this->execute();
        return $this->_query->fetchAll(PDO::FETCH_ASSOC);
    }

    //vraca jedan red
    public function single() {
        $this->execute();
        return $this->_query->fetch(PDO::FETCH_ASSOC);
    }

    public function getAssocArray($query) {
        $this->query($query);
        $this->execute();
        return $this->_query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function rowCount() {
        $this->execute();
        return $this->_query->rowCount();
    }


}