</head>
<body>

<nav class="navbar navbar-expand-md navbar-dark bg-dark">

    <div class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo URLROOT; ?>">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo URLROOT; ?>/users/register">Register</a>
            </li>
            <li class="nav-item">
                <?php if (isset($_SESSION['user_id'])) : ?>
                    <a class="nav-link" href="<?php echo URLROOT; ?>/users/logout">Log out</a>
                <?php else : ?>
                    <a class="nav-link" href="<?php echo URLROOT; ?>/users/login">Login</a>
                <?php endif; ?>
            </li>
        </ul>
        <form action="<?php echo URLROOT; ?>/users/result" method="POST" class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="text" name="search" placeholder="Search">
            <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
        </form>

    </div>
</nav>