<?php
    require_once 'libraries/Core.php';
    require_once 'libraries/Controller.php';
    require_once 'libraries/DB.php';
    require_once 'helpers/session_helper.php';
    require_once 'config/config.php';

    require_once 'views/includes/header.php';
    require_once 'views/includes/navigation.php';

    $init = new Core();