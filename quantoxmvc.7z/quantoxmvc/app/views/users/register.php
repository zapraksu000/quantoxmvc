<?php

?>

<div class="container">
    <h2>Register</h2>
    <br>
    <form action="<?php echo URLROOT; ?>/users/register" method="POST">
        <div class="form-group">
            <label for="name">Name: </label>
            <input type="text" class="form-control" name="name" id="name" value="">
            <?php echo $data['nameError']; ?>
        </div>
        <div class="field">
            <label for="email">Email: </label>
            <input type="email" class="form-control" name="email" id="email" value="">
            <?php echo $data['emailError']; ?>
        </div>
        <div class="form-group">
            <label for="password">Password: </label>
            <input type="password" class="form-control" name="password" id="password">
            <?php echo $data['passwordError']; ?>
        </div>
        <div class="form-group">
            <label for="password_again">Repeat password: </label>
            <input type="password" class="form-control" name="confirmPassword" id="confirmPassword">
            <?php echo $data['confirmPasswordError']; ?>
        </div>
        <div class="dropdown">
            <label for="type">Select type: </label>
            <select name="type" id="type">
                <?php
                $this->_db = DB::getInstance();
                $types = $this->_db->getAssocArray('SELECT * FROM type');

                foreach ($types as $type) {
                    echo "<option value='" . $type['type_name'] . "'>" . $type['type_name'] . "</option>";
                }
                ?>
            </select>
            <?php echo $data['typeError']; ?>
        </div>

        <div class="dropdown">
            <label for="subtype">Subtype: </label>
            <select name="subtype" id="subtype">
                <?php
                $this->_db = DB::getInstance();
                $subtypes = $this->_db->getAssocArray('SELECT * FROM subtype');

                foreach ($subtypes as $subtype) {
                    echo "<option value='" . $subtype['subtype_name'] . "'>" . $subtype['subtype_name'] . "</option>";
                }
                ?>
            </select>
            <?php echo $data['subtypeError']; ?>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-primary" value="Register">Register</button>
        </div>
    </form>
    <a href="<?php echo URLROOT; ?>/users/login">Already have account? Click here to login</a>
</div>