-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2021 at 02:11 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quantoxmvc`
--

-- --------------------------------------------------------

--
-- Table structure for table `subtype`
--

CREATE TABLE `subtype` (
  `subtype_id` int(11) NOT NULL,
  `subtype_name` varchar(255) NOT NULL,
  `type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subtype`
--

INSERT INTO `subtype` (`subtype_id`, `subtype_name`, `type_id`) VALUES
(1, 'Angular', 1),
(2, 'React', 1),
(3, 'Vue', 1),
(4, 'PHP', 2),
(5, 'NodeJS', 2);

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`type_id`, `type_name`) VALUES
(1, 'Front End Developer'),
(2, 'Back End Developer');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `user_subtype` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_email`, `user_password`, `user_type`, `user_subtype`) VALUES
(1, 'Pera', 'pera@email.com', '$2y$10$r.egjwpPJGYiKeVnvHLFiudffmUwegAvUkqKeln86syseLsV3VTJa', 'Front End Developer', 'Angular'),
(2, 'Mika', 'mika@gmail.com', '$2y$10$ESOKQOFJrtzVnFSBU.rk..l2ImfbdEV/RLlpeNrVVvScvAipEV60W', 'Front End Developer', 'React'),
(3, 'Laza', 'laza@yahoo.com', '$2y$10$0Fu0rh5MRlYKUzHUUq4vBuNnTzLRx0gDITkW4Pxbd1cYL6hY8rjbG', 'Front End Developer', 'Vue'),
(4, 'Zika', 'zika@mail.com', '$2y$10$Y8uoTx4oZYq0rS99tCHrXOOsAIdhCLiQrkyFa/kMNOttENG1qNyT6', 'Back End Developer', 'PHP'),
(5, 'Dima', 'dima@macor.com', '$2y$10$PxOjLoHZbfRH4P5.a7qBKePUCRztRkg9HoR1QZw4lHVOUXq27XwSK', 'Back End Developer', 'NodeJS');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `subtype`
--
ALTER TABLE `subtype`
  ADD PRIMARY KEY (`subtype_id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `subtype`
--
ALTER TABLE `subtype`
  MODIFY `subtype_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
