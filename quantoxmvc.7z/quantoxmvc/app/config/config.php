<?php
//parametri za bazu
define('DB_HOST', 'localhost');
define('DB_NAME', 'quantoxmvc');
define('DB_USER', 'root');
define('DB_PASS', '');


//APPROOT
define('APPROOT', dirname(dirname(__FILE__)));

//URLROOT
define('URLROOT', 'http:/quantoxmvc');

//Sitename
define('SITENAME', 'QuantoxMVC');