<?php
$this->_db = DB::getInstance();

$results = $this->_db->resultSet();

?>
<div class="container">
    <h2>Search result</h2>
    <br>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Type</th>
            <th scope="col">Subtype</th>
        </tr>
        </thead>
        <tbody>

        <?php
        if (!empty($results)) {
            foreach ($results as $result) {
                echo
                    "<tr>
                        <td>" . $result['user_name'] . "</td>
                        <td>" . $result['user_email'] . "</td>
                        <td>" . $result['user_type'] . "</td>
                        <td>" . $result['user_subtype'] . "</td>
                     </tr>";
                }
            }
        ?>

        </tbody>
    </table>
</div>