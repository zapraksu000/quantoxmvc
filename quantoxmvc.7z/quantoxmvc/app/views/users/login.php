<?php

?>

<div class="container">
    <h2>Login</h2>
    <br>
<form action="<?php echo URLROOT; ?>/users/login" method="POST">
    <div class="form-group">
        <label for="email">Email: </label>
        <input type="email" class="form-control" name="email" id="email" value="">
        <?php echo $data['emailError']; ?>
    </div>
    <div class="form-group">
        <label for="password">Password: </label>
        <input type="password" class="form-control" name="password" id="password">
        <?php echo $data['passwordError']; ?>
    </div>
    <button type="submit" class="btn btn-primary" value="Log in">Log in</button>
</form>
    <a href="<?php echo URLROOT; ?>/users/register">Don't have account? Click here to register</a>
</div>