<?php
class User {
    private $_db;
    public function __constructor() {
        $this->_db = DB::getInstance();
    }

    public function register($data) {

        $this->_db = DB::getInstance();
        //print_r($data);
        $this->_db->query('INSERT INTO users (user_name, user_email, user_password, user_type, user_subtype) VALUES(:name, :email, :password, :type, :subtype)');


        //bindovanje vrednosti
        $this->_db->bind(':name', $data['name']);
        $this->_db->bind(':email', $data['email']);
        $this->_db->bind(':password', $data['password']);
        $this->_db->bind(':type', $data['type']);
        $this->_db->bind(':subtype', $data['subtype']);

        //izvrsavanje
        if ($this->_db->execute()) {
            return true;
        } else {
            return false;
        }


    }

    //provera da li je email zauzet
    public function findUserByEmail($email) {

        $this->_db = DB::getInstance();

        $this->_db->query('SELECT * FROM users WHERE user_email = :email');

        $this->_db->bind(':email', $email);

        //ukoliko vrati vise 0, email postoji u bazi
        if($this->_db->rowCount() > 0) {
            return true;
        } else {
            return false;
        }

    }

    public function login($email, $password) {

        $this->_db = DB::getInstance();
        $this->_db->query('SELECT * FROM users WHERE user_email = :email');

        $this->_db->bind(':email', $email);

        $row = $this->_db->single();

        if (password_verify($password, $row['user_password'])) {
            //echo "radi";
            return $row;
        } else {
            return false;
        }
    }

    public function search($search) {
        $this->_db = DB::getInstance();

        $this->_db->query("SELECT * FROM users WHERE user_name LIKE :search OR user_email LIKE :search");

        $this->_db->bind(':search', '%' . $search . '%');

        //print_r($this->_db->resultSet());

    }

}