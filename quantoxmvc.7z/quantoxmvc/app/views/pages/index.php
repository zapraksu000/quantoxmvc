<div class="container">

    <h2>Home</h2>
    <br>

    <?php

    if (isset($_SESSION['user_name'])) {
        echo "<h2> Welcome " . $_SESSION['user_name'] . "!</h2>";
    }
    ?>

</div>
